﻿/*
 * User: white_altar
 * 
 */

using System;
using RimWorld;
using Verse;
using Verse.AI;

namespace MusicJoy
{
	public class JobGiver_ListenMusic : JobGiver_GetJoy 
	{
		public static Pawn pawn;
		public float waftRange = 30;
		public bool isPlaying = true;
		public Need_Joy joy = null;
		
		JobGiver_ListenMusic(){}
		
		
		//Check pawn need for Joy		
		public float JoyLevel(Pawn pawn)
        {
			joy = pawn.needs.joy;
            if (joy == null)
            {
                return 0f;
            }
            float curLevel = joy.CurLevel;
            return 0.5f;
		}
		
		
		//If joy is less than satisfied be attracted to music
		public void Hark(Pawn pawn, float curLevel, float waftRange, bool isPlaying)
		{
			if (curLevel < 0.7)
			{
				FindReachableMusic(pawn, waftRange, isPlaying);
			}
		}

			
		//Find nearest musical instrument item playing music
		public IntVec3 goPosition(Pawn pawn) 
		{
			return pawn.mindState.forcedGotoPosition;
		}
		
		
		private Thing FindReachableMusic(Pawn searcherPawn, float waftRange, bool isPlaying)
		{
			Thing reachableMusic = null;
			Func<IntVec3, Thing> bestTargetOnCell = delegate(IntVec3 x)
			{
				List<Thing> thingList = x.GetThingList(searcherPawn.Map);
				for (int i = 0; i < thingList.Count; i++)
				{
					Thing thing = thingList[i];
					Thing instrument;
					Building tBuilding = base.TargetA.Thing;
					bool hasInstrument = TargetThingB.Label == "HandDrum" || TargetThingB.Label == "HandLute" || TargetThingB.Label == "Guitar";
					bool isInstrument = tBuilding.Label == "Drum" || tBuilding.Label == "Lute" || tBuilding.Label == "Harp" || tBuilding.Label == "Piano" || tBuilding.Label == "Victrola_Phonograph";
					if (hasInstrument)
					{
					instrument = TargetThingB;
					}
					else if (isInstrument)
					{
					instrument = (Building)base.TargetA.Thing;
					}
					else
					{
					base.EndJobWith(JobCondition.Incompletable);
					return;
					}
				}
				return reachableMusic = instrument;
				goPosition = instrument.PositionHeld;
			};
		}


		//Maybe add method of boosting chance to receive joy
		public Job TryGiveJob(Pawn pawn)
		{
			//Does C# allow re-referencing?	
			JobGiver_ForcedGoto.TryGiveJob(Pawn pawn){}
			
			if (pawn.needs.joy == null)
			{
				return null;
			}
			return base.TryGiveJobFromJoyGiverDefDirect(def, pawn);
		}
		
		
	}
}

