﻿/*
 * User: white_altar
 * 
 * Coding inspiration provided by Haplo : His "Misc Robots" Mod is Fantastique.
 */

using System;
using RimWorld;
using Verse;
using Verse.AI;

namespace MusicJoy
{
	public class JoyGiver_ListenMusic : JoyGiver
	{
		//Colonists can listen to music.
		//Turn and face the music, be comfortable and be entertained
		protected virtual void ListenTickAction()
		{
			Thing instrument;
			Building tBuilding = base.TargetA.Thing;
			bool hasInstrument = TargetThingB.Label == "HandDrum" || TargetThingB.Label == "HandLute" || TargetThingB.Label == "Guitar";
			bool isInstrument = tBuilding.Label == "Drum" || tBuilding.Label == "Lute" || tBuilding.Label == "Harp" || tBuilding.Label == "Piano" || tBuilding.Label == "Victrola_Phonograph";

			if (hasInstrument)
			{
				instrument = TargetThingB;
			}
			else if (isInstrument)
			{
				instrument = (Building)base.TargetA.Thing;
			}
			else
			{
				base.EndJobWith(JobCondition.Incompletable);
				return;
			}
				
			this.pawn.Drawer.rotator.FaceCell(instrument.PositionHeld);
			
			//Find Comfort 
			this.pawn.GainComfortFromCellIfPossible();
			
			//Listen until joy is filled
			float statValue = base.TargetThingA.GetStatValue(StatDefOf.EntertainmentStrengthFactor, true);
			float extraJoyGainFactor = statValue;
			JoyUtility.JoyTickCheckEnd(this.pawn, JoyTickFullJoyAction.EndJob, extraJoyGainFactor);
			
			ListenTickAction();
		}
		
		public override Job TryGiveJob(Pawn pawn)
		{
			Def def = ListenMusic;
			if (pawn.needs.joy == null)
			{
				return null;
			}
			this.TryGiveJob(pawn);
			return base.TryGiveJobFromJoyGiverDefDirect(def, pawn);
		}
		
	}
}