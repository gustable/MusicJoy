﻿/*
 * User: white_altar
 * 
 * Coding inspiration provided by Haplo : His "Misc Robots" Mod is Fantastique.
 */

using System;
using System.Collections.Generic;
using RimWorld;
using Verse;
using Verse.AI;

namespace MusicJoy
{
	public class JobDriver_ListenMusic : JobDriver
	{
		//For colonists in bed; taken from WatchTV
		protected override IEnumerable<Toil> MakeNewToils()
		{
			this.EndOnDespawnedOrNull(TargetIndex.A, JobCondition.Incompletable);
			yield return Toils_Reserve.Reserve(TargetIndex.A, base.CurJob.def.joyMaxParticipants);
			yield return Toils_Reserve.Reserve(TargetIndex.B, 1);
			bool hasBed = base.TargetC.HasThing && base.TargetC.Thing is Building_Bed;
			Toil listen;
			if (hasBed)
			{
				this.KeepLyingDown(TargetIndex.C);
				yield return Toils_Reserve.Reserve(TargetIndex.C, ((Building_Bed)base.TargetC.Thing).SleepingSlotsCount);
				yield return Toils_Bed.ClaimBedIfNonMedical(TargetIndex.C, TargetIndex.None);
				yield return Toils_Bed.GotoBed(TargetIndex.C);
				listen = Toils_LayDown.LayDown(TargetIndex.C, true, false, true, true);
			}
			else  //For colonists not in bed
			{
				if (base.TargetC.HasThing)
				{
					yield return Toils_Reserve.Reserve(TargetIndex.C, 1);
				}
				yield return MoveToListen();
				listen = new Toil();
			}
			listen.AddPreTickAction(delegate
			{
				this.ListenTickAction();
			});
			listen.AddFinishAction(delegate
			{
				JoyUtility.TryGainRecRoomThought(this.pawn);
			});
			listen.defaultCompleteMode = ToilCompleteMode.Delay;
			listen.defaultDuration = base.CurJob.def.joyDuration;
			yield return listen;
		}
		
		//Moving colonists not in bed within hearing range of music (Try (WatchBuildingUtility.GetWatchCellRect(toWatch.def, toWatch.Position, toWatch.Rotation, list[i]).Contains(pawn.Position))
		protected virtual Toil MoveToListen()
		{
			Thing instrument;
			Building tBuilding = (Building)base.TargetA.Thing;
			bool hasInstrument = TargetThingB.Label == "HandDrum" || TargetThingB.Label == "HandLute" || TargetThingB.Label == "Guitar";
			bool isInstrument =  tBuilding.Label == "Drum" || tBuilding.Label == "Lute" || tBuilding.Label == "Harp" || tBuilding.Label == "Piano" || tBuilding.Label == "Victrola_Phonograph";

			if (hasInstrument)
			{
				instrument = TargetThingB;
			}
			else if (isInstrument)
			{
				instrument = (Building)base.TargetA.Thing;
			}
			
			if (hasInstrument || isInstrument)
			{
				return Toils_Goto.GotoCell(TargetIndex.B, PathEndMode.InteractionCell);
			}
			else
			{
				return null;
			}
		}
			
		
	}
}